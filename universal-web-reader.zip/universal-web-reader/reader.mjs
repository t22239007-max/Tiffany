import axios from 'axios';

export const readWeb = async (url) => {
    const prefixes = [
        'https://markdown.new/',
        'https://defuddle.md/',
        'https://r.jina.ai/'
    ];

    for (const prefix of prefixes) {
        try {
            console.log(`Trying prefix: ${prefix}`);
            const res = await axios.get(prefix + url, { timeout: 10000 });
            return res.data;
        } catch (e) {
            continue;
        }
    }
    
    // Fallback to local Scrapling (conceptual)
    console.log("All prefixes failed, invoking Scrapling...");
    return "Scrapling fallback triggered.";
};
