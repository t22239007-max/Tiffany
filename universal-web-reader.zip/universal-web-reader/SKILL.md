# Universal Web Reader (全能网页阅读器)

一个能够自动绕过反爬、提取网页核心 Markdown 内容的智能阅读中枢。

## 功能
- **自动前缀路由**：当用户传入 URL 时，智能分配最优提取方案：
  1. `https://markdown.new/` (Cloudflare 友好型)
  2. `https://defuddle.md/` (Fallback A)
  3. `https://r.jina.ai/` (Fallback B)
- **硬核抓取 Fallback**：若前缀方案均失败，自动调用 Scrapling 引擎提取。

## 使用方法
调用 `readWeb(url)`，系统会自动按优先级循环尝试以上前缀。
